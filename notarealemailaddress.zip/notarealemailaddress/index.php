<?php
header('future-x-location: 48.4512345');
header('future-y-location: 48.4512345');
header('serving=phone: UUID');
header('location-time: 14913904');
header('your-points: 14');
header('their-points: 15');

?>

$_GET["_location-x"];
$_GET["_location-y"];

