<?php
$id=$_GET["id"];
if($id!=null)
{
	echo '<?xml version="1.0" encoding="UTF-8" ?>';
	echo  '<location>10</location>';
	
	$locx = $_GET['location-x'];
	$locy = $_GET['location-y'];
	$currentscore = $_GET['current_score'];
	$id = $_GET['id'];
	$timestamp = time();
		
	mysql_connect($host, $db_user, $db_pass) or 
     	 	die ("A server error has occurred.");
	mysql_select_db($dbn) or 
    		die ("A database error has occurred.");
	    	
	    	$insert = mysql_query("INSERT INTO current_players VALUES ('". $id . "','".$locx."','".$locy."','".$timestamp."','".$currentscore."')");
	
		if($insert) {
			echo "Listing successfully added to the database.<br/><br/>";
			}else{
			echo "Listing not successful";
			}

}
else
echo 'hi';
?>