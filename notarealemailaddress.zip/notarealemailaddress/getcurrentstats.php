<?php include('config.php');


	$locx = $_GET['location-x'];
	$locy = $_GET['location-y'];
	$currentscore = $_GET['current_score'];
	$id = $_GET['id'];
	$timestamp = time();
		
	mysql_connect($host, $db_user, $db_pass) or 
     	 	die ("A server error has occurred.");
	mysql_select_db($dbn) or 
    		die ("A database error has occurred.");
	    	
	    	$data = mysql_query("SELECT * from current_game");
		
		if($insert = mysql_fetch_array($data)) {
			
			//echo "" . $insert[current_longitude] . " ";
						
			//echo "" . $insert[current_latitude] . " ";
			echo "<currentstats>";
			echo "<id>" . $insert[current_player] . "</id>";

			
			echo "<future_longitude>" . $insert[future_longitude] . "</future_longitude>";
			
			echo "<future_latitude>" . $insert[future_latitude] . "</future_latitude>";
			
			echo "<current_player>" . $insert[current_player] . "</current_player>";
			
						
			echo "<timestamp>" . $insert[timestamp] . "</timestamp>";

			
			echo "<player_one_score>" . $insert[player_one_score] . "</player_one_score>";

			echo "<player_two_score>" . $insert[player_two_score] . "</player_two_score>";

			echo "</currentstats>";

		}else{
		}

?>