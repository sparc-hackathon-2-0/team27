<?php include('config.php');?>
<?


	$locx = $_GET['location-x'];
	$locy = $_GET['location-y'];
	$currentscore = $_GET['current_score'];
	$id = $_GET['id'];
	$timestamp = time();
		
	mysql_connect($host, $db_user, $db_pass) or 
     	 	die ("A server error has occurred.");
	mysql_select_db($dbn) or 
    		die ("A database error has occurred.");
	    		    	assert($id!= null);

	    	$insert = mysql_query("INSERT INTO current_players VALUES ('". $id . "','".$locx."','".$locy."','".$timestamp."','".$currentscore."')");
	
		if($insert) {
			
			$insert = mysql_query("SELECT * FROM current_players");
			
			$num_rows = mysql_num_rows($insert);
			if ($num_rows >= 2){

			 	$data= mysql_query("SELECT * from current_players order by timestamp desc LIMIT 2")
			 	     or mysql_error("No matches were found.");

				$longitudep1 = 0;
				$latitudep1 = 0;
				$longitudep2 = 0;
				$latitudep2 = 0;
				$current_player = 0;
				$firstrun = false;
			        while($info = mysql_fetch_array($data)){
			        	
			        	if ($firstrun == false){
			        		$firstrun = true;
			        		$longitudep1 =$info['location-x'];
						$latitudep1 =$info['location-y'];
			        	}else{
			        	
			        		$longitudep2 =$info['location-x'];
						$latitudep2 =$info['location-y'];
						$current_player = $info['device_id'];
					}
									
				}	
					
					
					list($whole, $decimal) = explode('.', $longitudep1);
						
						$futureLong = $decimal;
							
					list($whole, $decimal) = explode('.', $longitudep2);

					$futureLong = abs(rand( $decimal, $futureLong));

						$futureLong = $whole . ".". $futureLong;
					
					list($whole, $decimal) = explode('.', $latitudep1);
						
						$futureLat = $decimal;
							
					list($whole, $decimal) = explode('.', $latitudep2);

						$futureLat = abs( rand( $decimal, $futureLat));
						$futureLat = $whole . "." .$futureLat;
					

					$longitude = ($longitudep1 + $longitudep2) / 2;
					$latitude = ($latitudep1 + $latitudep2) / 2;

				
					
					
					$futurelong = 0.0;
					$futurelat = 0.0;
					$timestamp = time()+10000;
				$sql = "DELETE FROM current_game";
				if(mysql_query($sql))
					{}
				;
				
				
				$sql = "INSERT INTO current_game VALUES ('".$current_player."', '".$longitude."', '".$latitude ."', '".$futureLong ."', '".$futureLat."', '".$timestamp."', '0', '0');";
				
				
				
				if(mysql_query($sql))
				{
					echo "game_started";
				}else{
					echo "something happened bad";
				}
				
			}
		}else{
			echo "";
		}


?>