<?php
//1330628
$host="localhost";
$db_user = "softcode_pong";
$db_pass = "clemson5";
$dbn = "softcode_lifepong";
?>