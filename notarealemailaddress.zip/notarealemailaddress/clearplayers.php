<?php include('config.php');?>

<?
mysql_connect($host, $db_user, $db_pass) or 
     	 	die ("A server error has occurred.");
	mysql_select_db($dbn) or 
    		die ("A database error has occurred.");

				$sql = "DELETE FROM current_players";
				if(mysql_query($sql))
					{echo "deleted";}
				;
?>